<template>
  <nav class="navbar">
    <RouterLink to="/">Home</RouterLink>
    <RouterLink to="/create">Add Post</RouterLink>
  </nav>
</template>

